
var express= require('express')
var _ = require('underscore')
var bp= require('body-parser')
var app= express()
app.use(express.static('public'))
app.use(bp.json())
var middleware = require("./middleware.js")
app.use(middleware.logger)



var userdata=[]
var uid=1;
app.post('/adduser',(req,res) =>{
var data= req.body;
data.id=uid++;
userdata.push(data);
res.send('user is added')

})
app.get('/loaddata',middleware.requireAuth,(req,res) =>{
    console.log(res.statusCode)
    res.status(200).send()
    console.log(res)
    
})

app.get('/loaddata/:id',(req,res)=>{
   var myid= parseInt(req.params.id)
   var matchedValue = _.findWhere(userdata,{id:myid});
   if(matchedValue){
       res.json(matchedValue)
   }
   else {
       res.status(404).send()
   }
   console.log(res)
})
app.delete('/deleteuser/:id',(req,res) =>{
    var myid= parseInt(req.params.id)
    var matchedValue = _.findWhere(userdata,{id:myid});
    if(matchedValue){ 
        userdata=_.without(userdata,matchedValue)
        res.send(matchedValue)
    }
})

app.listen(3000,()=>{
    console.log('server is ready')
})