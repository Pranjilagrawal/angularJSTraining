var em = require("events").EventEmitter

var emitter = new em();

var lc=0;
emitter.setMaxListeners(110)
function somecallback(){
    emitter.on("callme",function(){
        lc++
    })
}

for (var i=0;i<90;i++){
    somecallback()
}
emitter.emit("callme",lc)
console.log("worked",lc)