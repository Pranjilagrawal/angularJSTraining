console.log("welcome to nodejs")
const getBlog = ()=>{
    setTimeout(()=>{

        return{
            title:"javascript demo"
        }
    },2000)

}

const bp = getBlog()
console.log(bp.title)