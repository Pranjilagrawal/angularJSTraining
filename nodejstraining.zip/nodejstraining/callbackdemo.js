
function getUser(id,mycallback){
    setTimeout(()=>{
        console.log("getting user from multiple sources")
mycallback({
    id: id,
    name:"demo"
})
},1000)}

function getBlogs(username,callback){
    setTimeout(()=>{
        console.log("calling fb for loadig blogs")
    callback(["post1","post2","post3"])

},1000)}

function getComments(post,callback){
    setTimeout(()=>{
        console.log("calling fb for loadig comments"+ post)
    callback(["comments for" + post])

},1000)}

getUser(101,(user)=>{
    getBlogs(user.name,(blogpost)=>{
        getComments(blogpost[0],(comments)=>{
        console.log(user,blogpost[0],comments)
        })
    })
})