
function getUser(id){
    return new Promise((resolve,reject) => {
        setTimeout(() => {
            console.log('Getting the user for the multiple sources')
    resolve ({
             id:id,
                name: 'amarjeet'
            })
    
        },1000)
    })
    
    }
    function getBlogs(username) {
        return new Promise((resolve,reject) => {
        setTimeout(() =>{
            console.log('calling FB for loading blogs');
            resolve(['Post1','Post2','Post3'])
        },1000)
    })
    }
    
    function getComments(post) {
        return new Promise((resolve,reject) => {
        setTimeout(() =>{
            console.log('calling FB for loading comments' + post);
            resolve(['Comments for ' + post])
        },1000)
    })
    }
    
    getUser(101)
    .then(user => getBlogs(user.name))
    .then(blogpost => getComments(blogpost[0]))
    .then(comments => console.log(comments))
    .catch(err => console.log(err))
       
    
    