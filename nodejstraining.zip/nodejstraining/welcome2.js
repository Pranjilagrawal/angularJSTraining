
const getBlog = (mycallback)=>{
    setTimeout(()=>{
mycallback({
    title:"javascript demo"
})

       

},2000)}


getBlog((bp) =>{
    console.log(bp.title)

})