var em = require("events").EventEmitter

var emitter = new em();

emitter.on('onswipe',function(){
    console.log('App is starting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.on('onswipe',function(){
    console.log('System is booting')
})
emitter.emit('onswipe')