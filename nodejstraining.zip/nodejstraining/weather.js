var weather = require('./weatherapp.js')
var location = require('./location.js')
var argv = require('yargs')
.option('location' , {

    alias: 'l',
    demand: true,
    description: 'Location to fetch weather',
    type: 'string'

}).help ('help')
.argv
if(typeof argv.l =='string' && argv.l.length > 0) {
    weather(argv.l,function(weather) {
        console.log(weather)
    })
     } 
else {
    location(function(location){
        console.log("location not given")
        if(location) {
            weather(location.city,function(weather) {
                console.log(location)
                console.log(weather) 
        })
    }
else {
        console.log('unable to guess')
    }
    })
    }