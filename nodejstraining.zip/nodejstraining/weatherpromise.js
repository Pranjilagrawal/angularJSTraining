var weather = require('./weatherapppromise.js')
var location = require('./locationpromise.js')
var argv = require('yargs')

    .option('location', {

        alias: 'l',
        demand: false,
        description: 'Location to fetch weather',
        type: 'string'

    }).help('help')
    .argv
if (typeof argv.l === 'string' && argv.l.length > 0) {
    weather(argv.l).then(function (weather) {
        console.log(weather)
    })

} else {

    location().then(function (loc) {
        return weather(loc.city)
    }).then(function (weather) {
        console.log(weather)
    }).catch(function (err) {
        console.log(err)
    })
}